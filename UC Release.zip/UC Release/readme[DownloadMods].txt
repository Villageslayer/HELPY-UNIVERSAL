hi and thanks for reviewing this 
code is commented if the link in the readme is an issue just delete it please
as this is v0.5 the User experience is fucked to shit 
please delete the source folder after approval
