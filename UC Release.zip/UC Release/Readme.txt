NO LOGITECH MOUSE NEEDED THE GHUB INSTALL IS ONLY FOR THE DRIVER
DISABLE AUTOMATIC UPDATES IN GHUB SETTINGS 
IF IT STILL UPDATES 
https://www.laptopmag.com/articles/block-windows-10-programs-connecting-to-internet
FOLLOW THIS LINK TO SEE HOW TO BLOCK INTERNET ACCESS TO GHUB

THIS IS V0.5 THE MORE FEEDBACK I GET THE HIGHER THE CHANCE I WILL MAKE A BETTER UI

Step 1 install logitech Ghub V 2021.11
Step 2 open logitech Ghub V 2021.11
Step 3 open Word.exe file 
Step 4 Enter your DPI
Step 5 Use F5-F7 to control the script [Low,Medium,High]
Step 6 Launch Game
Step 7 goto Shooting range and test
Step 8 matchmake and Rank up

IF YOU PAID FOR THIS YOU GOT SCAMMED EVERYTHING I MAKE IS FOR FREE